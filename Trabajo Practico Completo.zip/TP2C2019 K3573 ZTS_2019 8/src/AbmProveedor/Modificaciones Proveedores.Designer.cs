﻿namespace FrbaOfertas.AbmProveedor
{
    partial class Modificaciones_Proveedores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_piso = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_depto = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_codigopostal = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_localidad = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_ciudad = new System.Windows.Forms.TextBox();
            this.txt_direccion = new System.Windows.Forms.TextBox();
            this.lbl_direccion = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.bt_cancelar = new System.Windows.Forms.Button();
            this.bt_habilitar = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.bt_modificar = new System.Windows.Forms.Button();
            this.bt_guardar = new System.Windows.Forms.Button();
            this.contenedor_estado = new System.Windows.Forms.GroupBox();
            this.txt_estado = new System.Windows.Forms.TextBox();
            this.contenedor_info_cliente = new System.Windows.Forms.GroupBox();
            this.cb_rubros = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_Contacto = new System.Windows.Forms.TextBox();
            this.txt_username = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_email = new System.Windows.Forms.TextBox();
            this.txt_telefono = new System.Windows.Forms.TextBox();
            this.txt_id = new System.Windows.Forms.TextBox();
            this.txt_RazonSoc = new System.Windows.Forms.TextBox();
            this.txt_CUIT = new System.Windows.Forms.TextBox();
            this.lbl_DNI = new System.Windows.Forms.Label();
            this.lbl_id = new System.Windows.Forms.Label();
            this.lbl_mail = new System.Windows.Forms.Label();
            this.lbl_apellido = new System.Windows.Forms.Label();
            this.lbl_nombre = new System.Windows.Forms.Label();
            this.lbl_telefono = new System.Windows.Forms.Label();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.contenedor_estado.SuspendLayout();
            this.contenedor_info_cliente.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.txt_piso);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.txt_depto);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.txt_codigopostal);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.txt_localidad);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.txt_ciudad);
            this.groupBox3.Controls.Add(this.txt_direccion);
            this.groupBox3.Controls.Add(this.lbl_direccion);
            this.groupBox3.Location = new System.Drawing.Point(317, 101);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox3.Size = new System.Drawing.Size(256, 187);
            this.groupBox3.TabIndex = 36;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Ubicacion del Cliente";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(12, 136);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 18);
            this.label6.TabIndex = 30;
            this.label6.Text = "Nº Piso";
            // 
            // txt_piso
            // 
            this.txt_piso.Location = new System.Drawing.Point(119, 135);
            this.txt_piso.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_piso.Name = "txt_piso";
            this.txt_piso.ReadOnly = true;
            this.txt_piso.Size = new System.Drawing.Size(131, 20);
            this.txt_piso.TabIndex = 29;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(12, 162);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 18);
            this.label5.TabIndex = 28;
            this.label5.Text = "Depto";
            // 
            // txt_depto
            // 
            this.txt_depto.Location = new System.Drawing.Point(119, 166);
            this.txt_depto.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_depto.Name = "txt_depto";
            this.txt_depto.ReadOnly = true;
            this.txt_depto.Size = new System.Drawing.Size(131, 20);
            this.txt_depto.TabIndex = 27;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(12, 104);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 18);
            this.label4.TabIndex = 26;
            this.label4.Text = "Codigo Postal";
            // 
            // txt_codigopostal
            // 
            this.txt_codigopostal.Location = new System.Drawing.Point(119, 103);
            this.txt_codigopostal.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_codigopostal.Name = "txt_codigopostal";
            this.txt_codigopostal.ReadOnly = true;
            this.txt_codigopostal.Size = new System.Drawing.Size(131, 20);
            this.txt_codigopostal.TabIndex = 25;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(12, 74);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 18);
            this.label3.TabIndex = 24;
            this.label3.Text = "Localidad";
            // 
            // txt_localidad
            // 
            this.txt_localidad.Location = new System.Drawing.Point(119, 73);
            this.txt_localidad.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_localidad.Name = "txt_localidad";
            this.txt_localidad.ReadOnly = true;
            this.txt_localidad.Size = new System.Drawing.Size(131, 20);
            this.txt_localidad.TabIndex = 23;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(12, 44);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 18);
            this.label2.TabIndex = 22;
            this.label2.Text = "Ciudad";
            // 
            // txt_ciudad
            // 
            this.txt_ciudad.Location = new System.Drawing.Point(119, 44);
            this.txt_ciudad.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_ciudad.Name = "txt_ciudad";
            this.txt_ciudad.ReadOnly = true;
            this.txt_ciudad.Size = new System.Drawing.Size(131, 20);
            this.txt_ciudad.TabIndex = 21;
            // 
            // txt_direccion
            // 
            this.txt_direccion.Location = new System.Drawing.Point(119, 16);
            this.txt_direccion.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_direccion.Name = "txt_direccion";
            this.txt_direccion.ReadOnly = true;
            this.txt_direccion.Size = new System.Drawing.Size(131, 20);
            this.txt_direccion.TabIndex = 20;
            // 
            // lbl_direccion
            // 
            this.lbl_direccion.AutoSize = true;
            this.lbl_direccion.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.lbl_direccion.Location = new System.Drawing.Point(12, 17);
            this.lbl_direccion.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_direccion.Name = "lbl_direccion";
            this.lbl_direccion.Size = new System.Drawing.Size(76, 18);
            this.lbl_direccion.TabIndex = 4;
            this.lbl_direccion.Text = "Direccion";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.bt_cancelar);
            this.groupBox2.Controls.Add(this.bt_habilitar);
            this.groupBox2.Location = new System.Drawing.Point(317, 292);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Size = new System.Drawing.Size(256, 83);
            this.groupBox2.TabIndex = 35;
            this.groupBox2.TabStop = false;
            // 
            // bt_cancelar
            // 
            this.bt_cancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.bt_cancelar.Location = new System.Drawing.Point(15, 48);
            this.bt_cancelar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bt_cancelar.Name = "bt_cancelar";
            this.bt_cancelar.Size = new System.Drawing.Size(233, 27);
            this.bt_cancelar.TabIndex = 12;
            this.bt_cancelar.Text = "Cancelar";
            this.bt_cancelar.UseVisualStyleBackColor = true;
            this.bt_cancelar.Click += new System.EventHandler(this.bt_cancelar_Click);
            // 
            // bt_habilitar
            // 
            this.bt_habilitar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.bt_habilitar.Location = new System.Drawing.Point(15, 16);
            this.bt_habilitar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bt_habilitar.Name = "bt_habilitar";
            this.bt_habilitar.Size = new System.Drawing.Size(233, 28);
            this.bt_habilitar.TabIndex = 13;
            this.bt_habilitar.Text = "Habilitar Proveedor";
            this.bt_habilitar.UseVisualStyleBackColor = true;
            this.bt_habilitar.Click += new System.EventHandler(this.bt_habilitar_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.bt_modificar);
            this.groupBox1.Controls.Add(this.bt_guardar);
            this.groupBox1.Location = new System.Drawing.Point(8, 292);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(304, 83);
            this.groupBox1.TabIndex = 34;
            this.groupBox1.TabStop = false;
            // 
            // bt_modificar
            // 
            this.bt_modificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.bt_modificar.Location = new System.Drawing.Point(15, 16);
            this.bt_modificar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bt_modificar.Name = "bt_modificar";
            this.bt_modificar.Size = new System.Drawing.Size(277, 27);
            this.bt_modificar.TabIndex = 24;
            this.bt_modificar.Text = "Modificar Proveedor";
            this.bt_modificar.UseVisualStyleBackColor = true;
            this.bt_modificar.Click += new System.EventHandler(this.bt_modificar_Click);
            // 
            // bt_guardar
            // 
            this.bt_guardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.bt_guardar.Location = new System.Drawing.Point(15, 47);
            this.bt_guardar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bt_guardar.Name = "bt_guardar";
            this.bt_guardar.Size = new System.Drawing.Size(277, 28);
            this.bt_guardar.TabIndex = 10;
            this.bt_guardar.Text = "Guardar Modificacion";
            this.bt_guardar.UseVisualStyleBackColor = true;
            this.bt_guardar.Click += new System.EventHandler(this.bt_guardar_Click);
            // 
            // contenedor_estado
            // 
            this.contenedor_estado.Controls.Add(this.txt_estado);
            this.contenedor_estado.Location = new System.Drawing.Point(317, 8);
            this.contenedor_estado.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.contenedor_estado.Name = "contenedor_estado";
            this.contenedor_estado.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.contenedor_estado.Size = new System.Drawing.Size(256, 90);
            this.contenedor_estado.TabIndex = 33;
            this.contenedor_estado.TabStop = false;
            this.contenedor_estado.Text = "Estado";
            this.contenedor_estado.Enter += new System.EventHandler(this.contenedor_estado_Enter);
            // 
            // txt_estado
            // 
            this.txt_estado.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_estado.Location = new System.Drawing.Point(21, 21);
            this.txt_estado.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_estado.Multiline = true;
            this.txt_estado.Name = "txt_estado";
            this.txt_estado.ReadOnly = true;
            this.txt_estado.Size = new System.Drawing.Size(229, 59);
            this.txt_estado.TabIndex = 14;
            this.txt_estado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_estado.TextChanged += new System.EventHandler(this.txt_estado_TextChanged);
            // 
            // contenedor_info_cliente
            // 
            this.contenedor_info_cliente.Controls.Add(this.cb_rubros);
            this.contenedor_info_cliente.Controls.Add(this.label7);
            this.contenedor_info_cliente.Controls.Add(this.txt_Contacto);
            this.contenedor_info_cliente.Controls.Add(this.txt_username);
            this.contenedor_info_cliente.Controls.Add(this.label1);
            this.contenedor_info_cliente.Controls.Add(this.txt_email);
            this.contenedor_info_cliente.Controls.Add(this.txt_telefono);
            this.contenedor_info_cliente.Controls.Add(this.txt_id);
            this.contenedor_info_cliente.Controls.Add(this.txt_RazonSoc);
            this.contenedor_info_cliente.Controls.Add(this.txt_CUIT);
            this.contenedor_info_cliente.Controls.Add(this.lbl_DNI);
            this.contenedor_info_cliente.Controls.Add(this.lbl_id);
            this.contenedor_info_cliente.Controls.Add(this.lbl_mail);
            this.contenedor_info_cliente.Controls.Add(this.lbl_apellido);
            this.contenedor_info_cliente.Controls.Add(this.lbl_nombre);
            this.contenedor_info_cliente.Controls.Add(this.lbl_telefono);
            this.contenedor_info_cliente.Location = new System.Drawing.Point(8, 8);
            this.contenedor_info_cliente.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.contenedor_info_cliente.Name = "contenedor_info_cliente";
            this.contenedor_info_cliente.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.contenedor_info_cliente.Size = new System.Drawing.Size(304, 280);
            this.contenedor_info_cliente.TabIndex = 32;
            this.contenedor_info_cliente.TabStop = false;
            this.contenedor_info_cliente.Text = "Informacion del Proveedor";
            // 
            // cb_rubros
            // 
            this.cb_rubros.AllowDrop = true;
            this.cb_rubros.Enabled = false;
            this.cb_rubros.FormattingEnabled = true;
            this.cb_rubros.Location = new System.Drawing.Point(162, 124);
            this.cb_rubros.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cb_rubros.Name = "cb_rubros";
            this.cb_rubros.Size = new System.Drawing.Size(131, 21);
            this.cb_rubros.TabIndex = 26;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(12, 251);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 18);
            this.label7.TabIndex = 25;
            this.label7.Text = "Contacto";
            // 
            // txt_Contacto
            // 
            this.txt_Contacto.Location = new System.Drawing.Point(162, 252);
            this.txt_Contacto.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_Contacto.Name = "txt_Contacto";
            this.txt_Contacto.ReadOnly = true;
            this.txt_Contacto.Size = new System.Drawing.Size(131, 20);
            this.txt_Contacto.TabIndex = 24;
            // 
            // txt_username
            // 
            this.txt_username.Location = new System.Drawing.Point(162, 56);
            this.txt_username.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_username.Name = "txt_username";
            this.txt_username.ReadOnly = true;
            this.txt_username.Size = new System.Drawing.Size(131, 20);
            this.txt_username.TabIndex = 23;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(12, 57);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 18);
            this.label1.TabIndex = 22;
            this.label1.Text = "Username";
            // 
            // txt_email
            // 
            this.txt_email.Location = new System.Drawing.Point(162, 217);
            this.txt_email.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_email.Name = "txt_email";
            this.txt_email.ReadOnly = true;
            this.txt_email.Size = new System.Drawing.Size(131, 20);
            this.txt_email.TabIndex = 21;
            // 
            // txt_telefono
            // 
            this.txt_telefono.Location = new System.Drawing.Point(162, 186);
            this.txt_telefono.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_telefono.Name = "txt_telefono";
            this.txt_telefono.ReadOnly = true;
            this.txt_telefono.Size = new System.Drawing.Size(131, 20);
            this.txt_telefono.TabIndex = 19;
            // 
            // txt_id
            // 
            this.txt_id.Location = new System.Drawing.Point(162, 21);
            this.txt_id.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_id.Name = "txt_id";
            this.txt_id.ReadOnly = true;
            this.txt_id.Size = new System.Drawing.Size(131, 20);
            this.txt_id.TabIndex = 18;
            // 
            // txt_RazonSoc
            // 
            this.txt_RazonSoc.Location = new System.Drawing.Point(162, 89);
            this.txt_RazonSoc.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_RazonSoc.Name = "txt_RazonSoc";
            this.txt_RazonSoc.ReadOnly = true;
            this.txt_RazonSoc.Size = new System.Drawing.Size(131, 20);
            this.txt_RazonSoc.TabIndex = 17;
            // 
            // txt_CUIT
            // 
            this.txt_CUIT.Location = new System.Drawing.Point(162, 159);
            this.txt_CUIT.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_CUIT.Name = "txt_CUIT";
            this.txt_CUIT.ReadOnly = true;
            this.txt_CUIT.Size = new System.Drawing.Size(131, 20);
            this.txt_CUIT.TabIndex = 15;
            // 
            // lbl_DNI
            // 
            this.lbl_DNI.AutoSize = true;
            this.lbl_DNI.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.lbl_DNI.Location = new System.Drawing.Point(12, 158);
            this.lbl_DNI.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_DNI.Name = "lbl_DNI";
            this.lbl_DNI.Size = new System.Drawing.Size(44, 18);
            this.lbl_DNI.TabIndex = 3;
            this.lbl_DNI.Text = "CUIT";
            // 
            // lbl_id
            // 
            this.lbl_id.AutoSize = true;
            this.lbl_id.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.lbl_id.Location = new System.Drawing.Point(12, 22);
            this.lbl_id.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_id.Name = "lbl_id";
            this.lbl_id.Size = new System.Drawing.Size(23, 18);
            this.lbl_id.TabIndex = 0;
            this.lbl_id.Text = "ID";
            // 
            // lbl_mail
            // 
            this.lbl_mail.AutoSize = true;
            this.lbl_mail.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.lbl_mail.Location = new System.Drawing.Point(12, 218);
            this.lbl_mail.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_mail.Name = "lbl_mail";
            this.lbl_mail.Size = new System.Drawing.Size(46, 18);
            this.lbl_mail.TabIndex = 6;
            this.lbl_mail.Text = "Email";
            // 
            // lbl_apellido
            // 
            this.lbl_apellido.AutoSize = true;
            this.lbl_apellido.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.lbl_apellido.Location = new System.Drawing.Point(12, 123);
            this.lbl_apellido.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_apellido.Name = "lbl_apellido";
            this.lbl_apellido.Size = new System.Drawing.Size(52, 18);
            this.lbl_apellido.TabIndex = 2;
            this.lbl_apellido.Text = "Rubro";
            // 
            // lbl_nombre
            // 
            this.lbl_nombre.AutoSize = true;
            this.lbl_nombre.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.lbl_nombre.Location = new System.Drawing.Point(12, 88);
            this.lbl_nombre.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_nombre.Name = "lbl_nombre";
            this.lbl_nombre.Size = new System.Drawing.Size(100, 18);
            this.lbl_nombre.TabIndex = 1;
            this.lbl_nombre.Text = "Razon Social";
            // 
            // lbl_telefono
            // 
            this.lbl_telefono.AutoSize = true;
            this.lbl_telefono.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.lbl_telefono.Location = new System.Drawing.Point(12, 187);
            this.lbl_telefono.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_telefono.Name = "lbl_telefono";
            this.lbl_telefono.Size = new System.Drawing.Size(71, 18);
            this.lbl_telefono.TabIndex = 5;
            this.lbl_telefono.Text = "Telefono";
            // 
            // Modificaciones_Proveedores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(580, 382);
            this.ControlBox = false;
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.contenedor_estado);
            this.Controls.Add(this.contenedor_info_cliente);
            this.Name = "Modificaciones_Proveedores";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Modificaciones_Proveedores";
            this.Load += new System.EventHandler(this.Modificaciones_Proveedores_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.contenedor_estado.ResumeLayout(false);
            this.contenedor_estado.PerformLayout();
            this.contenedor_info_cliente.ResumeLayout(false);
            this.contenedor_info_cliente.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.TextBox txt_piso;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.TextBox txt_depto;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.TextBox txt_codigopostal;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.TextBox txt_localidad;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox txt_ciudad;
        public System.Windows.Forms.TextBox txt_direccion;
        private System.Windows.Forms.Label lbl_direccion;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button bt_cancelar;
        private System.Windows.Forms.Button bt_habilitar;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button bt_modificar;
        private System.Windows.Forms.Button bt_guardar;
        private System.Windows.Forms.GroupBox contenedor_estado;
        public System.Windows.Forms.TextBox txt_estado;
        private System.Windows.Forms.GroupBox contenedor_info_cliente;
        private System.Windows.Forms.Label label7;
        public System.Windows.Forms.TextBox txt_Contacto;
        public System.Windows.Forms.TextBox txt_username;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox txt_email;
        public System.Windows.Forms.TextBox txt_telefono;
        public System.Windows.Forms.TextBox txt_id;
        public System.Windows.Forms.TextBox txt_RazonSoc;
        public System.Windows.Forms.TextBox txt_CUIT;
        private System.Windows.Forms.Label lbl_DNI;
        private System.Windows.Forms.Label lbl_id;
        private System.Windows.Forms.Label lbl_mail;
        private System.Windows.Forms.Label lbl_apellido;
        private System.Windows.Forms.Label lbl_nombre;
        private System.Windows.Forms.Label lbl_telefono;
        public System.Windows.Forms.ComboBox cb_rubros;
    }
}