﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FrbaOfertas.AbmCliente
{
    public partial class bajasClientes : Form
    {
        public bajasClientes()
        {
            InitializeComponent();
        }

        private void bt_deshabilitar_Click(object sender, EventArgs e)
        {

        }

        private void bt_habilitar_Click(object sender, EventArgs e)
        {

        }
    }
}
