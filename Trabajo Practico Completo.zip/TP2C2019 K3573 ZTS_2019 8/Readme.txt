 Curso: K3522
 Número de grupo: 10
 Integrantes:
	Saturni, Agustín - 159661-5
	Rodríguez Takahashi, Tomás - 164521-3
	Zeppa, Agustín - 163532-3
 Email del integrante responsable del grupo: agustinsaturni@gmail.com
